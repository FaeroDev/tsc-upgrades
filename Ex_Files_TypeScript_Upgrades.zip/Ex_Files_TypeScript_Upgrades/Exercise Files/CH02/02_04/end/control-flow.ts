let myControlFlow : string | number;

myControlFlow = "Hello I'm a string";
console.log(typeof myControlFlow);

myControlFlow = 4;
console.log(typeof myControlFlow);
