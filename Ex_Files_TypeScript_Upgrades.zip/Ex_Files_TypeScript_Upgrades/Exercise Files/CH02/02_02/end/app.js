var myControlFlow;
myControlFlow = "Hello I'm a string";
console.log(typeof myControlFlow);
myControlFlow = 4;
console.log(typeof myControlFlow);
var vreeg = { height: 100, widht: 50, ocean: 'Pacific' };
console.log(vreeg);
vreeg.ocean = 'Atlantic';
console.log(vreeg);
