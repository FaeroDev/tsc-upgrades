let myNullVar : null;
let myNullVar2 : undefined;

console.log(myNullVar);
console.log(myNullVar2);