// object type
const warriors: object = {};

console.log(typeof warriors);