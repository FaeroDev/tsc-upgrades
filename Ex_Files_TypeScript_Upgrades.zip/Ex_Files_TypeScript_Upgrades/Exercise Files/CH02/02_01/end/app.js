var myNullVar;
var myNullVar2;
console.log(myNullVar);
console.log(myNullVar2);
function selectWarrior(warrior) {
    switch (warrior.kind) {
        case 'archer':
            return "Our warrior is (" + warrior.kind + ")";
        case 'samurai':
            return "Our warrior is (" + warrior.kind + ")";
        case 'magician':
            return "Our warrior is (" + warrior.kind + ")";
    }
}
