let warriorName = 'Manny';

const warriorType = 'Samurai';

warriorName = 'Emmanuel';

warriorType = 'Archer';

console.log(warriorName, warriorType);
