var numberWarriors;
applyWarriors();
console.log(numberWarriors);
function applyWarriors() {
    numberWarriors = 20;
}
