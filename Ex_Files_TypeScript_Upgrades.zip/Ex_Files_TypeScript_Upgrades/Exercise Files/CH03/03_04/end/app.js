var milion = 1000000;
var phone = 5557342252;
var bytes = 4278976767;
var word = 50129;
console.log(milion, phone, bytes, word);
