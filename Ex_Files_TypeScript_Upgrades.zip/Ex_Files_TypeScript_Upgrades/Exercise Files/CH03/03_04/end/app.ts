const milion = 1_000_000;
const phone = 555_734_2252;
const bytes = 0xFF_0C_00_FF;
const word = 0b1100_0011_1101_0001;

console.log(milion, phone, bytes, word);
